CraveAI: https://sutcrave.streamlit.app/
